export class Address {
    addressid:number=0;
    buildingname:string='';
    streetno:string='';
    area:string='';
    city:string='';
    state:string='';
    country:string='';
    pin:string='';
}
