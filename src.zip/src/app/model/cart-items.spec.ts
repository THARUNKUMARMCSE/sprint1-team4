import { CartItems } from './cart-items';

describe('CartItems', () => {
  it('should create an instance', () => {
    expect(new CartItems()).toBeTruthy();
  });
});
